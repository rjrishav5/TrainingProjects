package com.rishav.javamini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaminiApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaminiApplication.class, args);
	}

}
