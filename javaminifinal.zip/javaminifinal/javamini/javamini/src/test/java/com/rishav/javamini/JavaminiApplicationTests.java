package com.rishav.javamini;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaminiApplicationTests {

	@Test
	void contextLoads() {
	}

}
